ArduCopter README

User Manual: http://copter.ardupilot.com/
Developer Manual: http://dev.ardupilot.com/