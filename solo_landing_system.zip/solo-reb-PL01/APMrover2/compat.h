
#ifndef __COMPAT_H__
#define __COMPAT_H__

#define HIGH 1
#define LOW 0

#endif // __COMPAT_H__

