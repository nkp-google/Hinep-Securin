AntennaTracker README

User Manual: http://antennatracker.ardupilot.com/
Developer Manual: http://dev.ardupilot.com/
