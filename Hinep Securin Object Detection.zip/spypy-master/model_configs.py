ANCHORS_PATH = "model/yolov2.anchors"
CLASSES_PATH = "model/yolov2.classes"
CONFIG_PATH = "model/yolov2.cfg"
WEIGHTS_PATH = "model/yolov2.weights" 
MODEL_IMAGE_SIZE = (608, 608)
MIN_CONFIDENCE = 0.5
MAX_OVERLAP = 0.35
