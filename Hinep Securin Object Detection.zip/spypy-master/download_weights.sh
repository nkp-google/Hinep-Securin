wget https://pjreddie.com/media/files/yolov2.weights
wget https://pjreddie.com/media/files/yolov2-tiny.weights
mv *.weights model/

